package no.hvl.dat152.main;

import no.hvl.dat152.TUI.StoreFront;
import no.hvl.dat152.utils.DBhandler;
import no.hvl.dat152.utils.GenerateProperties;

import java.util.Locale;
import java.util.ResourceBundle;

public class Main {
    public static void main(String[] args) {
        Locale locale = new Locale("es");
        ResourceBundle resourceBundle = ResourceBundle.getBundle("texts", locale);
        StoreFront.interfaceLoop(resourceBundle);
    }
}

