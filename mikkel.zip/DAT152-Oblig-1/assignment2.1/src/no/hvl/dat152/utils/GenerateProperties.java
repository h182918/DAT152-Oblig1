package no.hvl.dat152.utils;
import no.hvl.dat152.model.Description;

import java.io.*;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
public class GenerateProperties {

    public static void generate(List<Description> descriptions, Locale locale) {
        String localeString = locale.getLanguage();
        String fileString = "C:\\Users\\torke\\H2019\\DAT152\\DAT152-Oblig-1\\assignment2.1\\src\\resources\\products_" + localeString + "_descriptions.properties";
        try (OutputStream output = new FileOutputStream(fileString)) {
            Properties prop = new Properties();
            for (Description d : descriptions) {
                if(d.getLangCode().equals(localeString)){
                    prop.setProperty(d.getPno() + "", d.getText());
                }
            }
            // set the properties value
            // save properties to project root folder
            prop.store(output, null);

            //System.out.println(prop);

        } catch (IOException io) {
                io.printStackTrace();
        }

    }
    public static Properties getDescriptions(Locale locale){
        String localeString = locale.getLanguage();
        String fileString = "C:\\Users\\torke\\H2019\\DAT152\\DAT152-Oblig-1\\assignment2.1\\src\\resources\\products_" + localeString + "_descriptions.properties";
        try (InputStream input = new FileInputStream(fileString)) {
            Properties prop = new Properties();
            // load a properties file
            prop.load(input);
            return prop;
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
