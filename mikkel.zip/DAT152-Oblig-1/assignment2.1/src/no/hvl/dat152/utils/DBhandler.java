package no.hvl.dat152.utils;

import no.hvl.dat152.model.Description;
import no.hvl.dat152.model.Product;

import java.util.*;
import java.util.stream.Collectors;

public class DBhandler {
    private static List<Product> allItems;

    private static void fakeTheDB(Locale locale){
        allItems = createProducts();
        List<Description> descriptions = createDescriptions();
        generateResource(descriptions, locale);
    }

    public static List<Product> getAllItems(Locale locale){
        fakeTheDB(locale);
        return allItems;
    }

    private static List<Product> createProducts(){
        List<Product> products = new ArrayList<Product>();
        Product p1 = new Product(001, "White Coffee Cup (TM)", 6.50);
        Product p2 = new Product(002, "Black Coffee Cup (TM)", 4.75);
        products.add(p1);
        products.add(p2);
        return products;
    }

    private static List<Description> createDescriptions(){
        List<Description> descriptions = new ArrayList<Description>();
        descriptions.add(new Description(001, "en", "The ultimate white coffee cup!"));
        descriptions.add(new Description(002, "en", "The ultimate black coffee cup!"));
        descriptions.add(new Description(001, "es", "¡La mejor taza de café con leche!"));
        descriptions.add(new Description(002, "es", "¡La mejor taza de café negro!"));
        descriptions.add(new Description(001, "nb", "Den ultimate hvite kaffekoppen!"));
        descriptions.add(new Description(002, "nb", "Den ultimate svarte kaffekoppen!"));
        return descriptions;
    }

    private static void generateResource(List<Description> descriptions, Locale locale){
        GenerateProperties.generate(descriptions, locale);
    }
}

