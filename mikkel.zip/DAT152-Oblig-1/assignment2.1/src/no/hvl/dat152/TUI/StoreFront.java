package no.hvl.dat152.TUI;

import no.hvl.dat152.model.Cart;
import no.hvl.dat152.model.Description;
import no.hvl.dat152.model.Product;
import no.hvl.dat152.utils.DBhandler;
import no.hvl.dat152.utils.GenerateProperties;

import java.util.*;

public class StoreFront {
    private static boolean runStore = true;
    private static ResourceBundle resBoundle;
    private static List<Product> products;
    private static Cart cart;
    private static Properties descriptions;
    private static Scanner sc;

    public static void interfaceLoop(ResourceBundle res){
        products = DBhandler.getAllItems(res.getLocale());
        sc = new Scanner(System.in);
        resBoundle = res;
        cart = new Cart();
        descriptions = GenerateProperties.getDescriptions(resBoundle.getLocale());
        System.out.println(resBoundle.getString("welcomeMessage"));
        while (runStore){
            printMainMenuChoices();
            String userChoice = sc.nextLine();
            if (checkForValidChoice(userChoice)) {
                findAndRunChoice(userChoice);
            } else {
                System.out.println(resBoundle.getString("invalidChoice"));
            }
        }
    }

    public static void printMainMenuChoices() {

        System.out.println(resBoundle.getString("choiceOne"));
        System.out.println(resBoundle.getString("choiceTwo"));
        System.out.println(resBoundle.getString("choiceExit"));
    }

    public static boolean checkForValidChoice(String userChoice) {
        return userChoice.matches("\\b[129]\\b");
    }

    public static void findAndRunChoice(String userChoice){
        int choice = Integer.parseInt(userChoice);
        switch (choice) {
            case 1:
                displayStoreItems();
                break;
            case 2:
                displayCart();
                break;
            case 9:
                exitStore();
                break;
        }
    }

    private static void displayCart() {
        List<Product> display = cart.getCart();
        for(Product p:display){
            System.out.print(p.getpName() + ": ");
            System.out.println(descriptions.getProperty(p.getPno() + ""));
            System.out.println("----------------------------------------------------");
        }
    }

    private static void displayStoreItems(){
        for(Product p:products){
            System.out.print(p.getPno() + ") " + p.getpName() + ": ");
            System.out.println(descriptions.getProperty(p.getPno() + ""));
            System.out.println("----------------------------------------------------");
        }
        Boolean displayItems = true;
        while(displayItems) {
            System.out.println(resBoundle.getString("selectItem"));
            String userChoice = sc.nextLine();
            if (userChoice.equals("9")) {
                displayItems = false;
                System.out.println(resBoundle.getString("returnStore"));
            } else {
                int pno = Integer.parseInt(userChoice);
                for (Product p : products) {
                    if (p.getPno() == pno) {
                        cart.addToCart(p);
                        System.out.println(p.getpName() + " " + resBoundle.getString("addedCart"));
                        System.out.println("----------------------------------------------------");
                    }
                }
            }
        }
    }

    private static void exitStore() {
        runStore = false;
        System.out.println(resBoundle.getString("exitingStore"));
    }
}
