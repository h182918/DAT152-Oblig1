package no.hvl.dat152.model;

import java.util.List;

public class Description {
    public int pno;
    public String langCode;
    public String text;

    public Description(int pno, String langCode, String text) {
        this.pno = pno;
        this.langCode = langCode;
        this.text = text;
    }

    public int getPno() {
        return pno;
    }

    public String getLangCode() {
        return langCode;
    }

    public String getText() {
        return text;
    }
}

