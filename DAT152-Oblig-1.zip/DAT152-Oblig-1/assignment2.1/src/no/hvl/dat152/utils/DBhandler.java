package no.hvl.dat152.utils;

import no.hvl.dat152.model.Description;
import no.hvl.dat152.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DBhandler {
    private Map<Product, Description> allItems;

    public DBhandler(){
        fakeTheDB();
    }

    public void fakeTheDB(){
        List<Product> products = createProducts();
        List<Description> descriptions = createDescriptions();
    }

    public Map<Product, Description> getAllItems(){
        return allItems;
    }

    public List<Product> createProducts(){
        List<Product> products = new ArrayList<Product>();
        Product p1 = new Product(001, "White Coffee Cup (TM)", 6.50);
        Product p2 = new Product(002, "Black Coffee Cup (TM)", 4.75);
        products.add(p1);
        products.add(p2);
        return products;
    }

    public List<Description> createDescriptions(){
        List<Description> descriptions = new ArrayList<Description>();
        Description d1 = new Description(001, );
        Description d2 = new Description();
        return null;
    }




}

