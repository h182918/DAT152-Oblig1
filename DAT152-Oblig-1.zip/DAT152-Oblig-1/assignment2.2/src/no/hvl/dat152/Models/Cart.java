package no.hvl.dat152.Models;

public class Cart {
}
